from typing import Optional, Tuple

from graph import Graph


MENU = """
Seleccione una opción:
1. Agregar vértice
2. Agregar arista (no dirigida)
3. Recorrido en anchura (BFS)
4. Recorrido en profundidad (DFS)
5. Buscar vértice
6. Distancia entre dos nodos (basado en BFS)
7. Mostrar grafo
0. Salir
"""


def leer_opcion() -> str:
    return input("Opción: ").strip()


def solicitar_vertice(mensaje: str) -> str:
    return input(f"{mensaje}: ").strip()


def solicitar_peso() -> float:
    while True:
        try:
            return float(input("Peso de la arista: ").strip())
        except ValueError:
            print("El peso debe ser numérico.")


def mostrar_grafo(grafo: Graph) -> None:
    print("\nVértices:")
    for vertice in grafo.vertices():
        print(f"- {vertice}")

    print("\nAristas (origen, destino, peso):")
    for origen, destino, peso in grafo.edges():
        print(f"- {origen} -> {destino} (peso {peso})")


def recorrido(grafo: Graph, metodo: str) -> None:
    inicio = solicitar_vertice("Vértice inicial")
    if metodo == "bfs":
        resultado = grafo.bfs(inicio)
        nombre = "Recorrido en anchura"
    else:
        resultado = grafo.dfs(inicio)
        nombre = "Recorrido en profundidad"

    if not resultado:
        print("El vértice no existe en el grafo.")
        return

    print(f"\n{nombre} iniciando en {inicio}:")
    print(" -> ".join(resultado))


def buscar_vertice(grafo: Graph) -> None:
    vertice = solicitar_vertice("Ingrese el vértice a buscar")
    encontrado = grafo.has_vertex(vertice)
    mensaje = "encontrado" if encontrado else "no se encuentra"
    print(f"El vértice '{vertice}' {mensaje} en el grafo.")


def distancia_entre_nodos(grafo: Graph) -> None:
    origen = solicitar_vertice("Nodo origen")
    destino = solicitar_vertice("Nodo destino")
    resultado: Optional[Tuple[float, list[str]]] = grafo.distance_between(origen, destino)

    if resultado is None:
        print("No se encontró un camino entre los nodos especificados.")
        return

    distancia, camino = resultado
    print("Camino encontrado (basado en BFS):")
    print(" -> ".join(camino))
    print(f"Distancia total: {distancia}")


def agregar_arista(grafo: Graph) -> None:
    origen = solicitar_vertice("Origen")
    destino = solicitar_vertice("Destino")
    peso = solicitar_peso()
    grafo.add_edge(origen, destino, peso)
    print("Arista agregada correctamente.")


def pre_cargar_grafo(grafo: Graph) -> None:
    grafo.add_edge("A", "B", 2)
    grafo.add_edge("A", "C", 1)
    grafo.add_edge("B", "D", 3)
    grafo.add_edge("C", "D", 2)
    grafo.add_edge("C", "E", 4)
    grafo.add_edge("D", "E", 1)


def main() -> None:
    grafo = Graph()
    pre_cargar_grafo(grafo)

    while True:
        print(MENU)
        opcion = leer_opcion()

        if opcion == "1":
            grafo.add_vertex(solicitar_vertice("Nombre del vértice"))
        elif opcion == "2":
            agregar_arista(grafo)
        elif opcion == "3":
            recorrido(grafo, "bfs")
        elif opcion == "4":
            recorrido(grafo, "dfs")
        elif opcion == "5":
            buscar_vertice(grafo)
        elif opcion == "6":
            distancia_entre_nodos(grafo)
        elif opcion == "7":
            mostrar_grafo(grafo)
        elif opcion == "0":
            print("Hasta luego")
            break
        else:
            print("Opción inválida, intente nuevamente.")


if __name__ == "__main__":
    main()
