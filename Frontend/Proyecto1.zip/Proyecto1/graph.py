from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


@dataclass
class Graph:
    """Representa un grafo no dirigido con pesos en sus aristas."""

    adjacency: Dict[str, List[Tuple[str, float]]] = field(default_factory=dict)

    def add_vertex(self, vertex: str) -> None:
        """Agrega un vértice si no existe."""
        if vertex not in self.adjacency:
            self.adjacency[vertex] = []

    def add_edge(self, origin: str, destination: str, weight: float = 1.0) -> None:
        """Agrega una arista no dirigida entre dos vértices."""
        self.add_vertex(origin)
        self.add_vertex(destination)

        if not self._edge_exists(origin, destination):
            self.adjacency[origin].append((destination, weight))
        if not self._edge_exists(destination, origin):
            self.adjacency[destination].append((origin, weight))

    def _edge_exists(self, origin: str, destination: str) -> bool:
        return any(neighbor == destination for neighbor, _ in self.adjacency.get(origin, []))

    def has_vertex(self, vertex: str) -> bool:
        """Indica si el vértice existe en el grafo."""
        return vertex in self.adjacency

    def bfs(self, start: str) -> List[str]:
        """Realiza un recorrido en anchura desde el vértice inicial."""
        if start not in self.adjacency:
            return []

        visited: Set[str] = set()
        order: List[str] = []
        queue: deque[str] = deque([start])
        visited.add(start)

        while queue:
            vertex = queue.popleft()
            order.append(vertex)

            for neighbor, _ in self.adjacency.get(vertex, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        return order

    def dfs(self, start: str) -> List[str]:
        """Realiza un recorrido en profundidad desde el vértice inicial."""
        if start not in self.adjacency:
            return []

        visited: Set[str] = set()
        order: List[str] = []
        stack: List[str] = [start]

        while stack:
            vertex = stack.pop()
            if vertex in visited:
                continue

            visited.add(vertex)
            order.append(vertex)

            neighbors = sorted(self.adjacency.get(vertex, []), key=lambda item: item[0], reverse=True)
            for neighbor, _ in neighbors:
                if neighbor not in visited:
                    stack.append(neighbor)

        return order

    def distance_between(self, origin: str, destination: str) -> Optional[Tuple[float, List[str]]]:
        """Calcula la distancia entre dos nodos usando el recorrido en anchura."""
        if origin not in self.adjacency or destination not in self.adjacency:
            return None

        queue: deque[str] = deque([origin])
        parents: Dict[str, Optional[str]] = {origin: None}

        while queue:
            vertex = queue.popleft()
            if vertex == destination:
                break

            for neighbor, _ in self.adjacency.get(vertex, []):
                if neighbor not in parents:
                    parents[neighbor] = vertex
                    queue.append(neighbor)

        if destination not in parents:
            return None

        path = self._reconstruct_path(destination, parents)
        distance = self._calculate_path_weight(path)
        return distance, path

    def _reconstruct_path(self, destination: str, parents: Dict[str, Optional[str]]) -> List[str]:
        path: List[str] = []
        current: Optional[str] = destination
        while current is not None:
            path.append(current)
            current = parents.get(current)
        path.reverse()
        return path

    def _calculate_path_weight(self, path: List[str]) -> float:
        distance = 0.0
        for i in range(len(path) - 1):
            distance += self._edge_weight(path[i], path[i + 1])
        return distance

    def _edge_weight(self, origin: str, destination: str) -> float:
        for neighbor, weight in self.adjacency.get(origin, []):
            if neighbor == destination:
                return weight
        return 0.0

    def vertices(self) -> List[str]:
        return sorted(self.adjacency.keys())

    def edges(self) -> List[Tuple[str, str, float]]:
        seen: Set[Tuple[str, str]] = set()
        results: List[Tuple[str, str, float]] = []
        for origin, neighbors in self.adjacency.items():
            for destination, weight in neighbors:
                key = tuple(sorted((origin, destination)))
                if key not in seen:
                    seen.add(key)
                    results.append((origin, destination, weight))
        return sorted(results, key=lambda item: (item[0], item[1]))
