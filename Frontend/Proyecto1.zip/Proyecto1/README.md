# Proyecto 1 - Recorridos y operaciones sobre grafos

Aplicación de consola en Python para trabajar con un grafo no dirigido y ponderado. Incluye las operaciones solicitadas:

- Recorrido en anchura solicitando el nodo inicial.
- Recorrido en profundidad solicitando el nodo inicial.
- Búsqueda de un vértice (retorna booleano).
- Cálculo de la distancia entre dos nodos a partir del recorrido en anchura y la suma de pesos.

## Requisitos

- Python 3.10 o superior.

## Ejecución

Desde la carpeta `Proyecto1` ejecute:

```bash
python main.py
```

El programa precarga un grafo de ejemplo y ofrece un menú para agregar vértices o aristas y ejecutar las operaciones solicitadas.

## Pruebas

Ejecute la batería de pruebas unitaria con:

```bash
python -m unittest discover
```
