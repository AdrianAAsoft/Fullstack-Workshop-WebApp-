Proyecto Estructura Datos II

Objetivos
Utilizar las características de las estructuras No lineales Grafos y Arboles para la resolución de Problemas
Usar herramientas de desarrollo en la implementación de aplicaciones de Grafos.

Enunciado de problema
Utilice la teoría de grafos para agregar las opciones de menú siguientes: 
a.	Recorrido en Anchura. Se debe solicitar el nodo inicial al usuario. 
b.	Recorrido en Profundidad. Se debe solicitar el nodo inicial al usuario.
c.	Desarrollar el método Buscar Vértice y agregarlo como opción del menú.
i.	Parámetro: el vértice a buscar debe ser especificado por el usuario. Retorno: booleano, devolver verdadero en caso de encontrar el vértice, falso en caso contrario.
d.	Desarrollar un método para encontrar la distancia entre dos nodos, a partir de la suma de los pesos de los arcos que conforman el camino entre el nodo origen y destino, basado en el recorrido en anchura
Lineamientos de Entrega 
El proyecto se desarrollará en grupo de tres personas, la fecha de entrega es la semana 8 de clases.
El proyecto deberá sustentarse y explicar las rutinas más importantes, puede utilizar Java, C++ y Python para su desarrollo
